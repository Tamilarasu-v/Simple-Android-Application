package com.majeur.applicationsinfo;

public interface MainCallbacks {

    public void onItemSelected(String packageName);
}
