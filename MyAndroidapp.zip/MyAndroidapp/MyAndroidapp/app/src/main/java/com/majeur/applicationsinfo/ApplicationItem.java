package com.majeur.applicationsinfo;

import android.content.pm.ApplicationInfo;

public class ApplicationItem {
    ApplicationInfo applicationInfo;
    String label;
    Long date;
    Long size = -1L;
}
